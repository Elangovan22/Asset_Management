alter table AMS_INSTANCE add column ASSETID integer ;
