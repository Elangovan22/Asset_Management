alter table AMS_INSTANCE add column REQUESTEDTIME varchar(255) ;
