alter table AMS_INSTANCE add column ASSETNEEDEDDATE date ;
