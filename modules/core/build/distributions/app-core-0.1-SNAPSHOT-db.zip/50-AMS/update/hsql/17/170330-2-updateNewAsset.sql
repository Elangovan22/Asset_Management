alter table AMS_NEW_ASSET add column STATUS integer default 1 not null ;
